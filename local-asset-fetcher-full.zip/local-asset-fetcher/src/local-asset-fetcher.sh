#!/usr/bin/env bash
#
# Local Asset Fetcher (laf)
# A lightweight Bash utility that automates the downloading of public
# repositories and configuration files, automatically organizing them
# into categorized folders based on their file extension.
#
# Version: 1.0.0
# License: MIT
# Author: Local Asset Fetcher Contributors
#

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# Default configuration
VERSION="1.0.0"
DEFAULT_BASE_DIR="${HOME}/.local-assets"
BASE_DIR="${DEFAULT_BASE_DIR}"
VERBOSE=false
DRY_RUN=false
FORCE=false
CATEGORIZE=true
CLONE_DEPTH=1
USER_AGENT="Local-Asset-Fetcher/${VERSION}"

# Category mapping (extension -> folder)
declare -A CATEGORIES=(
    # Scripts
    [sh]="scripts"
    [bash]="scripts"
    [zsh]="scripts"
    [fish]="scripts"
    [py]="scripts"
    [js]="scripts"
    [ts]="scripts"
    [rb]="scripts"
    [pl]="scripts"
    [php]="scripts"
    [lua]="scripts"
    [go]="scripts"
    [rs]="scripts"
    [java]="scripts"
    [kt]="scripts"
    [swift]="scripts"
    [c]="scripts"
    [cpp]="scripts"
    [h]="scripts"
    [hpp]="scripts"
    [cs]="scripts"
    [ps1]="scripts"
    [bat]="scripts"
    [cmd]="scripts"

    # Configurations
    [json]="configs"
    [yaml]="configs"
    [yml]="configs"
    [toml]="configs"
    [ini]="configs"
    [conf]="configs"
    [cfg]="configs"
    [config]="configs"
    [env]="configs"
    [properties]="configs"
    [xml]="configs"
    [plist]="configs"
    [service]="configs"
    [timer]="configs"
    [socket]="configs"
    [desktop]="configs"
    [theme]="configs"
    [rc]="configs"

    # Documentation
    [md]="docs"
    [markdown]="docs"
    [txt]="docs"
    [rst]="docs"
    [adoc]="docs"
    [org]="docs"
    [pdf]="docs"
    [html]="docs"
    [htm]="docs"

    # Data
    [csv]="data"
    [tsv]="data"
    [sql]="data"
    [db]="data"
    [sqlite]="data"

    # Images / Assets
    [png]="assets"
    [jpg]="assets"
    [jpeg]="assets"
    [gif]="assets"
    [svg]="assets"
    [ico]="assets"
    [webp]="assets"
    [bmp]="assets"

    # Archives
    [zip]="archives"
    [tar]="archives"
    [gz]="archives"
    [tgz]="archives"
    [bz2]="archives"
    [xz]="archives"
    [7z]="archives"
    [rar]="archives"

    # Docker / Infra
    [dockerfile]="infra"
    [docker-compose]="infra"
    [compose]="infra"
    [tf]="infra"
    [hcl]="infra"
    [nix]="infra"
)

# Print helpers
info()  { echo -e "${BLUE}[INFO]${NC} $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
err()   { echo -e "${RED}[ERR]${NC}  $*" >&2; }
debug() { [[ "$VERBOSE" == true ]] && echo -e "${CYAN}[DBG]${NC}  $*"; }

usage() {
    cat <<EOF
${BOLD}Local Asset Fetcher (laf)${NC} v${VERSION}
Lightweight utility to download public repos & config files,
then organize them into categorized folders by extension.

${BOLD}USAGE${NC}
    laf [OPTIONS] <URL...>
    laf [OPTIONS] -f <file-with-urls>
    laf --init                  # Create default directory structure
    laf --list                  # List downloaded assets
    laf --clean                 # Remove empty category folders

${BOLD}OPTIONS${NC}
    -d, --dir <path>       Base directory (default: ~/.local-assets)
    -f, --file <path>      Read URLs from a file (one per line)
    -c, --no-categorize    Don't sort by extension (keep original names)
    -n, --dry-run          Show what would be done without downloading
    -F, --force            Overwrite existing files/folders
    -v, --verbose          Verbose output
    -q, --quiet            Suppress non-error output
    --depth <n>            Git clone depth (default: 1, 0 = full)
    -h, --help             Show this help
    --version              Show version

${BOLD}EXAMPLES${NC}
    # Download a single config file
    laf https://raw.githubusercontent.com/user/repo/main/.bashrc

    # Clone a public repository (shallow)
    laf https://github.com/user/dotfiles.git

    # Multiple sources
    laf https://example.com/config.yaml \\
        https://github.com/user/scripts.git \\
        https://raw.githubusercontent.com/user/repo/main/app.json

    # From a list
    laf -f my-assets.txt

    # Custom location
    laf -d ~/my-assets https://github.com/user/repo.git

${BOLD}CATEGORIES${NC}
    scripts/   – shell, python, js, go, rust, etc.
    configs/   – yaml, json, toml, conf, env, systemd units
    docs/      – md, txt, rst, pdf, html
    data/      – csv, sql, databases
    assets/    – images
    archives/  – zip, tar, gz...
    infra/     – Docker, Terraform, Nix
    repos/     – full git repositories
    other/     – everything else

${BOLD}DIRECTORY LAYOUT${NC}
    ~/.local-assets/
    ├── scripts/
    ├── configs/
    ├── docs/
    ├── data/
    ├── assets/
    ├── archives/
    ├── infra/
    ├── repos/
    └── other/

EOF
}

init_dirs() {
    local base="$1"
    mkdir -p "${base}"/{scripts,configs,docs,data,assets,archives,infra,repos,other}
    ok "Initialized directory structure at ${base}"
}

get_extension() {
    local filename="$1"
    local ext
    # Handle special cases first
    local lower
    lower=$(echo "$filename" | tr '[:upper:]' '[:lower:]')
    case "$lower" in
        *dockerfile*) echo "dockerfile"; return ;;
        *docker-compose*.yml|*docker-compose*.yaml|*compose*.yml|*compose*.yaml) echo "docker-compose"; return ;;
        *.tar.gz|*.tgz) echo "tgz"; return ;;
        *.tar.bz2) echo "bz2"; return ;;
        *.tar.xz) echo "xz"; return ;;
    esac
    ext="${filename##*.}"
    if [[ "$ext" == "$filename" ]]; then
        echo ""  # no extension
    else
        echo "$ext" | tr '[:upper:]' '[:lower:]'
    fi
}

get_category() {
    local ext="$1"
    if [[ -n "${CATEGORIES[$ext]:-}" ]]; then
        echo "${CATEGORIES[$ext]}"
    else
        echo "other"
    fi
}

is_git_url() {
    local url="$1"
    [[ "$url" =~ ^git@ ]] || \
    [[ "$url" =~ \.git$ ]] || \
    [[ "$url" =~ github\.com/.+/.+ ]] || \
    [[ "$url" =~ gitlab\.com/.+/.+ ]] || \
    [[ "$url" =~ bitbucket\.org/.+/.+ ]] || \
    [[ "$url" =~ codeberg\.org/.+/.+ ]] || \
    [[ "$url" =~ git\+http ]]
}

normalize_git_url() {
    local url="$1"
    # Convert github.com/user/repo to https://github.com/user/repo.git
    if [[ "$url" =~ github\.com/([^/]+)/([^/]+) ]]; then
        local user="${BASH_REMATCH[1]}"
        local repo="${BASH_REMATCH[2]%.git}"
        echo "https://github.com/${user}/${repo}.git"
    elif [[ "$url" =~ gitlab\.com/([^/]+)/([^/]+) ]]; then
        local user="${BASH_REMATCH[1]}"
        local repo="${BASH_REMATCH[2]%.git}"
        echo "https://gitlab.com/${user}/${repo}.git"
    else
        echo "$url"
    fi
}

get_repo_name() {
    local url="$1"
    local name
    name=$(basename "$url")
    name="${name%.git}"
    echo "$name"
}

download_file() {
    local url="$1"
    local dest_dir="$2"
    local filename
    filename=$(basename "${url%%\?*}")  # strip query params
    local dest="${dest_dir}/${filename}"

    if [[ -f "$dest" && "$FORCE" != true ]]; then
        warn "Already exists (use --force to overwrite): ${dest}"
        return 0
    fi

    if [[ "$DRY_RUN" == true ]]; then
        info "[DRY-RUN] Would download: ${url} → ${dest}"
        return 0
    fi

    debug "Downloading ${url} → ${dest}"
    if command -v curl >/dev/null 2>&1; then
        if curl -fsSL -A "$USER_AGENT" -o "$dest" "$url"; then
            ok "Downloaded: ${filename} → ${dest_dir}/"
        else
            err "Failed to download: ${url}"
            return 1
        fi
    elif command -v wget >/dev/null 2>&1; then
        if wget -q -U "$USER_AGENT" -O "$dest" "$url"; then
            ok "Downloaded: ${filename} → ${dest_dir}/"
        else
            err "Failed to download: ${url}"
            return 1
        fi
    else
        err "Neither curl nor wget found. Please install one of them."
        return 1
    fi
}

clone_repo() {
    local url="$1"
    local dest_dir="$2"
    local name
    name=$(get_repo_name "$url")
    local dest="${dest_dir}/${name}"

    if [[ -d "$dest" && "$FORCE" != true ]]; then
        warn "Repo already exists (use --force to re-clone): ${dest}"
        return 0
    fi

    if [[ "$DRY_RUN" == true ]]; then
        info "[DRY-RUN] Would clone: ${url} → ${dest}"
        return 0
    fi

    if ! command -v git >/dev/null 2>&1; then
        err "git is required to clone repositories. Please install git."
        return 1
    fi

    local depth_args=()
    if [[ "$CLONE_DEPTH" -gt 0 ]]; then
        depth_args=(--depth "$CLONE_DEPTH")
    fi

    debug "Cloning ${url} → ${dest}"
    if [[ -d "$dest" && "$FORCE" == true ]]; then
        rm -rf "$dest"
    fi

    if git clone "${depth_args[@]}" "$url" "$dest" 2>/dev/null; then
        ok "Cloned: ${name} → ${dest_dir}/"
    else
        # Try without depth if shallow fails (some repos disallow it)
        if git clone "$url" "$dest" 2>/dev/null; then
            ok "Cloned (full): ${name} → ${dest_dir}/"
        else
            err "Failed to clone: ${url}"
            return 1
        fi
    fi
}

process_url() {
    local url="$1"
    url=$(echo "$url" | xargs)  # trim whitespace
    [[ -z "$url" || "$url" =~ ^# ]] && return 0  # skip empty / comments

    info "Processing: ${url}"

    if is_git_url "$url"; then
        local normalized
        normalized=$(normalize_git_url "$url")
        local target="${BASE_DIR}/repos"
        mkdir -p "$target"
        clone_repo "$normalized" "$target"
    else
        # Treat as direct file download
        local filename
        filename=$(basename "${url%%\?*}")
        local ext
        ext=$(get_extension "$filename")
        local category="other"
        if [[ "$CATEGORIZE" == true ]]; then
            category=$(get_category "$ext")
        fi
        local target="${BASE_DIR}/${category}"
        mkdir -p "$target"
        download_file "$url" "$target"
    fi
}

list_assets() {
    local base="$1"
    if [[ ! -d "$base" ]]; then
        warn "No assets directory found at ${base}"
        return 0
    fi
    echo -e "${BOLD}Assets in ${base}${NC}"
    echo "----------------------------------------"
    for cat in scripts configs docs data assets archives infra repos other; do
        local dir="${base}/${cat}"
        if [[ -d "$dir" ]]; then
            local count
            count=$(find "$dir" -mindepth 1 -maxdepth 1 2>/dev/null | wc -l | tr -d ' ')
            if [[ "$count" -gt 0 ]]; then
                echo -e "${GREEN}${cat}/${NC} (${count})"
                find "$dir" -mindepth 1 -maxdepth 1 -printf "    %f\n" 2>/dev/null | head -20
                if [[ "$count" -gt 20 ]]; then
                    echo "    ... and $((count - 20)) more"
                fi
            fi
        fi
    done
}

clean_empty() {
    local base="$1"
    local cleaned=0
    for cat in scripts configs docs data assets archives infra repos other; do
        local dir="${base}/${cat}"
        if [[ -d "$dir" ]] && [[ -z "$(ls -A "$dir" 2>/dev/null)" ]]; then
            rmdir "$dir" 2>/dev/null && ((cleaned++)) || true
        fi
    done
    ok "Removed ${cleaned} empty category folder(s)"
}

# --- Main ---
main() {
    local urls=()
    local url_file=""
    local do_init=false
    local do_list=false
    local do_clean=false
    local quiet=false

    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help) usage; exit 0 ;;
            --version) echo "laf ${VERSION}"; exit 0 ;;
            -d|--dir) BASE_DIR="$2"; shift 2 ;;
            -f|--file) url_file="$2"; shift 2 ;;
            -c|--no-categorize) CATEGORIZE=false; shift ;;
            -n|--dry-run) DRY_RUN=true; shift ;;
            -F|--force) FORCE=true; shift ;;
            -v|--verbose) VERBOSE=true; shift ;;
            -q|--quiet) quiet=true; shift ;;
            --depth) CLONE_DEPTH="$2"; shift 2 ;;
            --init) do_init=true; shift ;;
            --list) do_list=true; shift ;;
            --clean) do_clean=true; shift ;;
            --) shift; urls+=("$@"); break ;;
            -*) err "Unknown option: $1"; usage; exit 1 ;;
            *) urls+=("$1"); shift ;;
        esac
    done

    if [[ "$quiet" == true ]]; then
        info() { :; }
        ok() { :; }
        warn() { :; }
        debug() { :; }
    fi

    if [[ "$do_init" == true ]]; then
        init_dirs "$BASE_DIR"
        exit 0
    fi

    if [[ "$do_list" == true ]]; then
        list_assets "$BASE_DIR"
        exit 0
    fi

    if [[ "$do_clean" == true ]]; then
        clean_empty "$BASE_DIR"
        exit 0
    fi

    # Collect URLs from file
    if [[ -n "$url_file" ]]; then
        if [[ ! -f "$url_file" ]]; then
            err "File not found: $url_file"
            exit 1
        fi
        while IFS= read -r line || [[ -n "$line" ]]; do
            urls+=("$line")
        done < "$url_file"
    fi

    if [[ ${#urls[@]} -eq 0 ]]; then
        err "No URLs provided."
        echo
        usage
        exit 1
    fi

    # Ensure base exists
    mkdir -p "$BASE_DIR"

    local success=0
    local fail=0
    for url in "${urls[@]}"; do
        if process_url "$url"; then
            ((success++)) || true
        else
            ((fail++)) || true
        fi
    done

    echo
    if [[ "$DRY_RUN" == true ]]; then
        info "Dry-run complete. ${success} item(s) would be processed."
    else
        ok "Done. ${success} succeeded, ${fail} failed."
        info "Assets stored under: ${BASE_DIR}"
    fi
}

main "$@"
