#!/usr/bin/env bash
set -euo pipefail

# Local Asset Fetcher installer
VERSION="1.0.0"
REPO_RAW="https://raw.githubusercontent.com/your-org/local-asset-fetcher/main"
INSTALL_DIR="${HOME}/.local/bin"
SCRIPT_NAME="laf"

echo "→ Installing Local Asset Fetcher v${VERSION}..."

# Create install dir
mkdir -p "${INSTALL_DIR}"

# Download the script
if command -v curl >/dev/null 2>&1; then
  curl -fsSL "${REPO_RAW}/src/local-asset-fetcher.sh" -o "${INSTALL_DIR}/${SCRIPT_NAME}"
elif command -v wget >/dev/null 2>&1; then
  wget -q "${REPO_RAW}/src/local-asset-fetcher.sh" -O "${INSTALL_DIR}/${SCRIPT_NAME}"
else
  echo "Error: need curl or wget" >&2
  exit 1
fi

chmod +x "${INSTALL_DIR}/${SCRIPT_NAME}"

# Ensure PATH
if [[ ":$PATH:" != *":${INSTALL_DIR}:"* ]]; then
  echo
  echo "Add this to your shell config (~/.bashrc, ~/.zshrc, etc.):"
  echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
  echo
fi

# Initialize default dirs
"${INSTALL_DIR}/${SCRIPT_NAME}" --init 2>/dev/null || true

echo "✓ Installed successfully!"
echo "  Binary : ${INSTALL_DIR}/${SCRIPT_NAME}"
echo "  Assets : ~/.local-assets"
echo
echo "Try it:"
echo "  laf --help"
echo "  laf --list"
