// Local Asset Fetcher — Landing page interactions

document.addEventListener('DOMContentLoaded', () => {
  // Newsletter form
  const newsletterForm = document.getElementById('newsletter-form');
  const formMessage = document.getElementById('form-message');

  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = newsletterForm.querySelector('input[type="email"]').value.trim();
      if (!email) return;

      // Demo only — would call an API in production
      formMessage.hidden = false;
      formMessage.textContent = `Thanks! ${email} is on the list. You'll hear from us soon.`;
      newsletterForm.reset();

      // Hide message after a few seconds
      setTimeout(() => {
        formMessage.hidden = true;
      }, 5000);
    });
  }

  // Paid subscribe modal
  const modal = document.getElementById('subscribe-modal');
  const subscribeBtn = document.getElementById('subscribe-btn');
  const teamBtn = document.getElementById('team-btn');
  const closeBtn = modal?.querySelector('.modal-close');
  const backdrop = modal?.querySelector('.modal-backdrop');
  const paidForm = document.getElementById('paid-form');

  function openModal() {
    if (modal) {
      modal.hidden = false;
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal() {
    if (modal) {
      modal.hidden = true;
      document.body.style.overflow = '';
    }
  }

  subscribeBtn?.addEventListener('click', openModal);
  closeBtn?.addEventListener('click', closeModal);
  backdrop?.addEventListener('click', closeModal);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  if (paidForm) {
    paidForm.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Demo only — no real payment processed.\n\nIn a real product this would redirect to Stripe Checkout or similar.');
      closeModal();
    });
  }

  teamBtn?.addEventListener('click', () => {
    alert('Thanks for your interest!\n\nIn a real product this would open a contact form or Calendly link for Team Pack sales.');
  });

  // Smooth scroll for anchor links (extra safety)
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Simple mobile menu toggle (placeholder – expands nav if needed)
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  mobileToggle?.addEventListener('click', () => {
    if (navLinks) {
      const isHidden = getComputedStyle(navLinks).display === 'none';
      navLinks.style.display = isHidden ? 'flex' : 'none';
      navLinks.style.flexDirection = 'column';
      navLinks.style.position = 'absolute';
      navLinks.style.top = '64px';
      navLinks.style.right = '4%';
      navLinks.style.background = 'var(--surface)';
      navLinks.style.padding = '1rem';
      navLinks.style.borderRadius = '12px';
      navLinks.style.border = '1px solid var(--border)';
      navLinks.style.gap = '1rem';
    }
  });
});
