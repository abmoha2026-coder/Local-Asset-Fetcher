# Usage Guide

## Basic Commands

```bash
# Show help
laf --help

# Show version
laf --version

# Create the default folder structure
laf --init
```

## Downloading Files

Any non-Git URL is treated as a direct file download:

```bash
laf https://example.com/config.yaml
laf https://raw.githubusercontent.com/user/repo/main/.tmux.conf
```

Files are placed into a category folder according to their extension.

## Cloning Repositories

URLs that look like Git repositories are cloned (shallow by default):

```bash
laf https://github.com/user/dotfiles.git
laf https://github.com/user/dotfiles          # .git is added automatically for GitHub/GitLab
laf --depth 0 https://github.com/user/repo.git  # full history
```

Cloned repos always go into the `repos/` folder.

## Batch Mode

Create a text file with one URL per line:

```bash
# assets.txt
https://github.com/user/scripts.git
https://example.com/app.json
# this is a comment
https://raw.githubusercontent.com/user/repo/main/nginx.conf
```

Then run:

```bash
laf -f assets.txt
```

## Custom Base Directory

```bash
laf -d ~/my-collected-assets https://github.com/user/repo.git
```

## Useful Flags

| Flag | Purpose |
|------|---------|
| `-n, --dry-run` | Preview without downloading |
| `-F, --force` | Overwrite existing files/repos |
| `-v, --verbose` | Extra logging |
| `-q, --quiet` | Only show errors |
| `-c, --no-categorize` | Put everything in the base dir (no subfolders) |
| `--list` | Show what is already downloaded |
| `--clean` | Remove empty category folders |

## Environment & Paths

Default location: `~/.local-assets`

You can change it per invocation with `-d` or by setting an alias:

```bash
alias laf='laf -d ~/assets'
```
